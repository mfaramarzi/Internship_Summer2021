#!/bin/bash
# install any software required (Ubuntu)
#
apt-get install -y python3 python3-pip g++
pip3 install gradescope-utils
