#include <bits/stdc++.h>

using namespace std;
typedef long double ld;

int main() {
    int n;
    cin >> n;

    float ans = 0;
    for(int i = 0; i < n; i++) {
        float l, r;
        cin >> l >> r;
        ans += l*r;
    }

    cout << fixed;
    cout.precision(2);
    cout << ans << endl;
}